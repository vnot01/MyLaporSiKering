<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost:3306");
define("DB_USER", "root_laporkering");
define("DB_PASSWORD", "f3rifebDR4GONLISTIO");
define("DB_DATABASE", "laporkering");
?>
